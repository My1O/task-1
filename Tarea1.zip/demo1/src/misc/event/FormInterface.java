package misc.event;

public interface FormInterface {
	void initComponents();
	void clear();
	void showForm();
	void showForm(boolean maximize);
}
