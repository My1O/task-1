package misc.util;

import java.math.BigDecimal;

public class Math {

	public static String getNumberToString(Double number) {
        BigDecimal d = new BigDecimal(number);
        long a = d.longValue();
        BigDecimal b = d.remainder(BigDecimal.ONE);
        if (b == BigDecimal.ZERO) {
            return String.valueOf(a);
        } else {
            return String.valueOf(number);
        }
    }
}
