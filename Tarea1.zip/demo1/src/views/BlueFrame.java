package views;

import java.awt.Color;
import java.awt.Frame;


import misc.event.FormInterface;

public class BlueFrame extends WFrame implements FormInterface{

	/**
	 * Camilo Castro
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public BlueFrame(Frame parentFrame) {
		super(parentFrame);
		initComponents();
	}
	
	@Override
	public void initComponents() {
		//no layout manager
		setLayout(null);
					
		setTitle("Ventana color Azul");
		setSize(350,350);
		setBackground(Color.blue);
		this.setResizable(false);
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showForm() {
		setVisible(true);
		
	}
	
	@Override
	public void showForm(boolean maximize) {
		// TODO Auto-generated method stub
		
	}
	
}
