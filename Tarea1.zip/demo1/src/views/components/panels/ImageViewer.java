package views.components.panels;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Panel;
import java.awt.TexturePaint;
import java.awt.Toolkit;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public class ImageViewer extends Panel{

	/**
	 *  Camilo Castro
	 */
	private static final long serialVersionUID = 1L;
	private final Toolkit toolkit;
	private BufferedImage bufferedImage;
	private Graphics graphics;
	private final MediaTracker tracker;
	private int width;
	private int height;
	
	public ImageViewer() {
		toolkit = Toolkit.getDefaultToolkit();
		tracker = new MediaTracker(this);
	}
	public void LoadImage(String fileName, boolean asResource)
	{
		Image tempImage;
		if(asResource) {
			tempImage = toolkit.getImage(getClass().getResource(fileName));
		}else {
			tempImage = toolkit.getImage(fileName);
		}
		
		Image image = tempImage.getScaledInstance(getWidth(), getHeight(), Image.SCALE_DEFAULT);
		tracker.addImage(image, 0);
		try {
			//carga toda las imagenes para uso posterior
			tracker.waitForAll();
		} catch (Exception e) {
		}
		
		width = image.getWidth(this);
		height = image.getHeight(this);
		
		bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		graphics = bufferedImage.getGraphics();
		graphics.drawImage(image,0,0,this);
		
		if(!asResource) {
			repaint();
		}
	}
	
	public void paint(Graphics g) {
		setBackground(Color.white);
		Graphics2D g2 = (Graphics2D) g;
		TexturePaint paint = new TexturePaint(bufferedImage, new Rectangle2D.Double(0,0,width, height));
		g2.setPaint(paint);
		g2.fill(new Rectangle2D.Double(0,0,width, height));
	}
}
