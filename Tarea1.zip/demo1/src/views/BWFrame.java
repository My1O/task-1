package views;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Frame;

import misc.event.FormInterface;

public class BWFrame extends WFrame implements FormInterface{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private  Canvas canvas;

	public BWFrame(Frame parentFrame) {
		super(parentFrame);
		initComponents();
		// TODO Auto-generated constructor stub
	}
	public void initComponents() {
		//no layout manager
		setLayout(null);
		canvas = new Canvas();
		canvas.setSize(150,200);
		canvas.setBackground(Color.blue);
		add("South", canvas);
		
		setTitle("Azul y blanco");
		setSize(300,200);
		setLocationRelativeTo(null);
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showForm() {
		setVisible(true);
		
	}
	
	@Override
	public void showForm(boolean maximize) {
		// TODO Auto-generated method stub
		
	}
}
