package views;

import java.awt.Button;
import java.awt.Frame;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import misc.event.FormInterface;

public class FramePrincipal extends Frame implements FormInterface{
	/**
	 * Camilo Castro - primer asignacion 
	 * Botones con opciones para cada combinacion de color
	 * Boton de calculos basicos solicitados
	 */
	private static final long serialVersionUID = 1L;
	
	private Button button1;
	private Button button2;
	private Button button3;
	private Button button4;
	private Button button5;
	
	private final Frame instance;
	//initializing using constructor
	public FramePrincipal() {
		initComponents();
		instance = this;
		
	}
	
	@Override
	public void initComponents() {
		//agregamos titulo al frame
		setTitle("Menu Principal");
		// sin layout manager
		setLayout(null);
		
		//creando boton 1
		button1 = new Button("Azul");
		//estableciendo la posicion del boton en la pantalla
		button1.setBounds(90,50,100,32);
		//agregando el boton al frame
		add(button1);
		
		// creando el boton 2
		button2 = new Button("Azul y blanco");
		//posicion del boton en la pantalla
		button2.setBounds(90,100,100,32); 
		//agregando boton 2 al frame
		add(button2);
		
		// creando el boton 3
		button3 = new Button("Verde");
		//posicion del boton en la pantalla
		button3.setBounds(90,150,100,32); 
		//agregando boton 3 al frame
		add(button3);
		
		//creando el boton 4
		button4 = new Button("Fucsia");		
		//posicion del boton en la pantalla
		button4.setBounds(90,200,100,32);
		//agregando el boton al frame
		add(button4);
		
		//inicio del boton 5
		button5 = new Button("Calcular");
		button5.setBounds(90,250,100,32);
		add(button5);
	
		//agregamos tamaño al frame
		setSize(300,300);
		
		addWindowListener (new WindowAdapter() {
			@Override
		public void windowClosing(WindowEvent e) {
			System.exit(0);
		}	
		});
		//boton azul
		button1.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				BlueFrame bf = new BlueFrame(instance);
				bf.showForm();
			}
		});
		//boton Azul y blanco
		button2.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				BWFrame bwf = new BWFrame(instance);
				bwf.showForm();
			}
		});
		
		//boton verde
		button3.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				GreenFrame gf = new GreenFrame(instance);
				gf.showForm();
			}
		});
		
		button4.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				FucsiaFrame ff = new FucsiaFrame(instance);
				ff.showForm();
			}
		});
		button5.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				MathFrame mf = new MathFrame(instance);
				mf.showForm();
			}
		});
	}
				

	@Override
	public void clear() {
		// TODO Auto-generated method stub
	}

	@Override
	public void showForm() {
		//establecemos el frame visible, por defecto no es visible
		setVisible(true);
		setLocationRelativeTo(null);
		toFront();
	}

	@Override
	public void showForm(boolean maximize) {
		// TODO Auto-generated method stub
		
	}
}