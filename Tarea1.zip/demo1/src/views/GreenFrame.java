package views;

import java.awt.Color;
import java.awt.Frame;

import misc.event.FormInterface;

public class GreenFrame extends WFrame implements FormInterface{

	/**
	 *  Camilo Castro
	 */
	private static final long serialVersionUID = 1L;

	public GreenFrame(Frame parentFrame) {
		super(parentFrame);
		initComponents();
		// TODO Auto-generated constructor stub
	}
	@Override
	public void initComponents() {
		//no layout manager
		setLayout(null);
							
		setTitle("Ventana color Verde");
		setSize(380,250);
		setLocationRelativeTo(null);
		setBackground(Color.green);
		this.setResizable(false);
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showForm() {
		setVisible(true);
		
	}
	
	@Override
	public void showForm(boolean maximize) {
		// TODO Auto-generated method stub
		
	}

}
