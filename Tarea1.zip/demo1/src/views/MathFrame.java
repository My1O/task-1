package views;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;

import controlers.ControladorMatematica;
import models.MathOperation;

public class MathFrame extends WFrame{

	/**
	 * Camilo Castro
	 */
	private static final long serialVersionUID = 1L;
	private Label label1, label2, label3;
	private TextField textField1, textField2, textField3;
	
	private CheckboxGroup group1;
	
	private Checkbox checkbox1, checkbox2, checkbox3, checkbox4;
	private Button button1, button2;
	private ControladorMatematica cm;
	

	public MathFrame(Frame parentFrame) {
		super(parentFrame);
		initComponents();
		// TODO Auto-generated constructor stub
	}
	public void initComponents() {
		setLayout(null);
		setTitle("Operaciones Matematicas");
		
		cm = new ControladorMatematica(MathFrame.this);
		// inicio de label y textfield 1
		label1 = new Label("Numero 1");
		label1.setBounds(20,50,100,32);
		add(label1);
		
		textField1 = new TextField("");
		textField1.setBounds(122,50,100,32);
		textField1.addKeyListener(cm);
		add(textField1);
		
		//inicio de textfield y label 2
		label2 = new Label("Numero 2");
		label2.setBounds(20,84,100,32);
		add(label2);
		
		textField2 = new TextField("");
		textField2.setBounds(122,84,100,32);
		textField2.addKeyListener(cm);
		add(textField2);
		
		//inicio de label y textfield 3
		label3 = new Label("Resultado");
		label3.setBounds(20,120,100,32);
		add(label3);
		
		textField3 = new TextField("");
		textField3.setBounds(122,118,100,32);
		textField3.setEditable(false);
		textField3.addKeyListener(cm);
		add(textField3);
		
		//inicio del contenedor de checkbox - todos en group1
		group1 = new CheckboxGroup();
		//checkbox de suma
		checkbox1 = new Checkbox("Suma", group1, true);
		checkbox1.setBounds(260,50,100,24);
		add(checkbox1);
		//checkbox de resta
		checkbox2 = new Checkbox("Resta", group1, false);
		checkbox2.setBounds(260,75,100,24);
		add(checkbox2);
		//checkbox de multiplicar
		checkbox3 = new Checkbox("Multiplicacion", group1, false);
		checkbox3.setBounds(260,100,100,24);
		add(checkbox3);
		//checkbox de dividir
		checkbox4 = new Checkbox("Division", group1, false);
		checkbox4.setBounds(260,125,100,24);
		add(checkbox4);
		
		//boton de calcular
		button2 = new Button("Borrar");
		button2.setBounds(180,175,100,32);
		button2.setActionCommand("clean");
		button2.addActionListener(cm);
		add(button2);
		
		//boton borrar
		button1 = new Button("Calcular");
		button1.setBounds(40,175,100,32);
		button1.setActionCommand("calculate");
		button1.addActionListener(cm);
		add(button1);
		
		setSize(390,230);
	}
	
	public MathOperation getData() {
		MathOperation mo = new MathOperation();
		mo.setTerm1(Double.parseDouble(textField1.getText()));
		mo.setTerm2(Double.parseDouble(textField2.getText()));
		
		Checkbox cb = group1.getSelectedCheckbox();
		
		switch(cb.getLabel()) {
		case "Suma" -> mo.setOperation("suma");
		case "Resta" -> mo.setOperation("resta");
		case "Multiplicacion" -> mo.setOperation("multiplicar");
		case "Division" -> mo.setOperation("dividir");
		default -> mo.setOperation("none");
		}
		//retorna un objeto MathOperation
		return mo;
	}
	public void showResult(String result) {
		textField3.setText(result);
	}
	public void clean() {
		textField1.setText("");
		textField2.setText("");
		textField3.setText("");
		textField1.requestFocus();
	}
}
