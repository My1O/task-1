package main;
import views.*;

public class Main {

	public static void main(String[] args) {
	FramePrincipal FP = new FramePrincipal();
	FP.showForm();
	 
	// BlueFrame bf = new BlueFrame();
	 
	 //bf.showForm();
	}

}
