package controlers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import models.MathOperation;
import views.MathFrame;

public class ControladorMatematica implements ActionListener, KeyListener{

	private final MathFrame frame;
	private MathOperation operation;
	
	public ControladorMatematica(MathFrame mathframe) {
		frame = mathframe;
		operation = new MathOperation();
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// valida lo seleccionado
		char c = e.getKeyChar();
		if(!(Character.isDigit(c) || c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_ENTER || c == '.')) {
			e.consume();
		}
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		//selecciona una opcion del switch
		switch(e.getActionCommand()) {
		case "calculate" ->
		{
			operation = frame.getData();
			frame.showResult(operation.getResultAsString());
		}
		case "clean" -> frame.clean();
		}
		
	}

}
