package models;

import misc.util.Math; 

public class MathOperation {
	private double term1;
	private double term2;
	private double result;
	private String operation;
	
	public MathOperation()
	{
		term1 = 0d;
		term2 = 0d;
	}
	public MathOperation(Double term1, Double term2) {
		this.term1 = term1;
		this.term2 = term2;
	}
	public Double getTerm1() {
		return term1;
	}
	public Double getTerm2() {
		return term2;
	}
	public void setTerm1(Double term1) {
		this.term1 = term1;
	}
	public void setTerm2(Double term2) {
		this.term2 = term2;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	
	private void resolve() {
		result = switch (getOperation()) {
		case "suma" -> term1 + term2;
		case "resta" -> term1 - term2;
		case "multiplicar" -> term1 * term2;
		case "dividir" -> term1 / term2;
		default -> 0d;
		};
	}
	public Double getResult() {
		resolve();
		return result;
	}
	public void setResult(Double result)
	{
		this.result = result;
	}
	public String getResultAsString() {
		resolve();
		return Math.getNumberToString(result);
	}
}
