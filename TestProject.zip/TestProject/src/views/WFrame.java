package views;

import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import misc.event.FormInterface;

public class WFrame extends Frame implements FormInterface {

    private static final long serialVersionUID = 1L;

    Frame parentFrame;

    public WFrame(Frame parentFrame) {
        this.parentFrame = parentFrame;
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (parentFrame != null) {
                    parentFrame.setVisible(true);
                }
                dispose();
            }
        });
    }

    @Override
    public void initComponents() {
        // TODO Auto-generated method stub		
    }

    @Override
    public void clean() {
        // TODO Auto-generated method stub	
    }

    @Override
    public void showForm() {
        if (parentFrame != null) {
            parentFrame.setVisible(false);
        }
        setVisible(true);
        setLocationRelativeTo(null);
        toFront();
  
    }

    @Override
    public void showForm(boolean maximize) {
        if (parentFrame != null) {
            parentFrame.setVisible(false);
        }
        setVisible(true);
        setLocationRelativeTo(null);
        if (maximize) {
            setExtendedState(getExtendedState() | MAXIMIZED_BOTH);
        }
        toFront();
    }
}
